import Shell from "@/components/shell";
import PromptBuilder from "@/components/prompt-builder";
import { currentUser } from "@/server/auth";
export const dynamic = "force-dynamic";
export default async function Builder() { return <Shell user={await currentUser()} active="Prompt builder"><PromptBuilder/></Shell>; }
