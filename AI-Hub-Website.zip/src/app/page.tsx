import Hub from "@/components/hub";
import { currentUser } from "@/server/auth";
import { listContent, statistics } from "@/server/catalog";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export default async function Page({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const query = await searchParams;
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(query)) if (typeof value === "string") params.set(key, value);
  return <Hub initial={listContent(params)} stats={statistics()} user={await currentUser()} initialQuery={params.toString()} />;
}
