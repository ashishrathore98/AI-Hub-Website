import Link from "next/link";
import { redirect } from "next/navigation";
import { currentUser } from "@/server/auth";
import { database } from "@/server/db";
import { getContent, initializeCatalog } from "@/server/catalog";
import Shell from "@/components/shell";
import ResourceCard from "@/components/resource-card";
export const dynamic = "force-dynamic";
export default async function Saved() {
  const user = await currentUser(); if (!user) redirect("/login?next=/saved");
  initializeCatalog();
  const rows = database().prepare("SELECT content_id,completed FROM activity WHERE user_id=? AND bookmarked=1").all(user.id);
  const items = rows.flatMap(r => { const item = getContent(String(r.content_id)); return item ? [{ item, complete: !!r.completed }] : []; });
  return <Shell user={user} active="saved"><div className="page-title"><span className="eyebrow">YOUR PERSONAL COLLECTION</span><h1>Saved resources</h1><p>Your bookmarks stay with your account, whichever device you use.</p></div>{items.length ? <div className="prompt-grid">{items.map(({ item, complete }) => <ResourceCard key={item.id} item={item} complete={complete}/>)}</div> : <div className="empty"><h2>A place for useful ideas</h2><p>Save a guide or prompt while reading it and find it here later.</p><Link className="primary-button" href="/">Explore resources →</Link></div>}</Shell>;
}
