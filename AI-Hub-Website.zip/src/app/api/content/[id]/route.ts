import { getContent, revisions, saveContent, validateContent } from "@/server/catalog";
import { requireUser } from "@/server/auth";
import { assertOrigin, failure, HttpError, jsonBody, response } from "@/server/http";
export const runtime = "nodejs";
type Context = { params: Promise<{ id: string }> };
export async function GET(request: Request, context: Context) {
  try {
    const admin = new URL(request.url).searchParams.get("admin") === "true";
    if (admin) await requireUser(true);
    const content = getContent((await context.params).id, admin);
    if (!content) throw new HttpError(404, "Content was not found.");
    return response({ content, ...(admin ? { revisions: revisions(content.id) } : {}) });
  } catch (error) { return failure(error); }
}
export async function PUT(request: Request, context: Context) {
  try {
    assertOrigin(request); const user = await requireUser(true); const input = await jsonBody(request);
    if (!Number.isInteger(input.version)) throw new HttpError(400, "A version number is required.");
    return response({ content: saveContent(validateContent(input), user.id, (await context.params).id, Number(input.version)) });
  } catch (error) { return failure(error); }
}
