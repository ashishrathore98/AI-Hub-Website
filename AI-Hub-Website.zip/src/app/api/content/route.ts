import { listContent, saveContent, validateContent } from "@/server/catalog";
import { requireUser } from "@/server/auth";
import { assertOrigin, failure, jsonBody, response } from "@/server/http";
export const runtime = "nodejs";
export async function GET(request: Request) {
  try {
    const params = new URL(request.url).searchParams;
    const admin = params.get("admin") === "true";
    if (admin) await requireUser(true);
    return response(listContent(params, admin));
  } catch (error) { return failure(error); }
}
export async function POST(request: Request) {
  try {
    assertOrigin(request); const user = await requireUser(true);
    return response({ content: saveContent(validateContent(await jsonBody(request)), user.id) }, 201);
  } catch (error) { return failure(error); }
}
