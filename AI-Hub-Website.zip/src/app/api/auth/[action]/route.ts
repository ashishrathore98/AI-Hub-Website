import { authenticate, changePassword, currentUser, logout, rateLimit } from "@/server/auth";
import { assertOrigin, failure, HttpError, jsonBody, response } from "@/server/http";
export const runtime = "nodejs";
export async function GET(_: Request, context: { params: Promise<{ action: string }> }) {
  try {
    if ((await context.params).action !== "me") throw new HttpError(404, "Not found.");
    return response({ user: await currentUser(), registrationEnabled: process.env.ALLOW_REGISTRATION === "true" });
  } catch (error) { return failure(error); }
}
export async function POST(request: Request, context: { params: Promise<{ action: string }> }) {
  try {
    assertOrigin(request); const { action } = await context.params;
    if (action === "logout") { await logout(); return response({ ok: true }); }
    if (action === "password") { await changePassword(await jsonBody(request)); return response({ ok: true }); }
    if (action !== "login" && action !== "register") throw new HttpError(404, "Not found.");
    // Only trust a proxy-provided address when the deployment explicitly opts in.
    const client = process.env.TRUST_PROXY === "true" ? (request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown") : "local";
    rateLimit(`auth-client:${client}`, 60, 15 * 60_000);
    return response({ user: await authenticate(await jsonBody(request), action === "register") });
  } catch (error) { return failure(error); }
}
