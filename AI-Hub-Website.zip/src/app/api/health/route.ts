import { database } from "@/server/db";
import { response } from "@/server/http";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export function GET() {
  try { database().prepare("SELECT 1").get(); return response({ status: "ok" }); }
  catch (error) { console.error("Health check failed", error); return response({ status: "unavailable" }, 503); }
}
