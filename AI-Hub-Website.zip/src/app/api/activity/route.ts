import { requireUser } from "@/server/auth";
import { database } from "@/server/db";
import { getContent } from "@/server/catalog";
import { assertOrigin, failure, HttpError, jsonBody, response } from "@/server/http";
export const runtime = "nodejs";
export async function GET() {
  try {
    const user = await requireUser();
    const rows = database().prepare(`SELECT a.content_id,a.bookmarked,a.completed FROM activity a
      JOIN content c ON c.id=a.content_id WHERE a.user_id=? AND c.status='published'`).all(user.id);
    return response({ bookmarks: rows.filter(r => r.bookmarked).map(r => r.content_id), completed: rows.filter(r => r.completed).map(r => r.content_id) });
  } catch (error) { return failure(error); }
}
export async function PUT(request: Request) {
  try {
    assertOrigin(request); const user = await requireUser(); const input = await jsonBody(request);
    if (typeof input.contentId !== "string" || !getContent(input.contentId)) throw new HttpError(404, "Content was not found.");
    if ((input.field !== "bookmarked" && input.field !== "completed") || typeof input.value !== "boolean") throw new HttpError(400, "Choose a bookmark or completion status.");
    const column = input.field;
    database().prepare(`INSERT INTO activity(user_id,content_id,${column}) VALUES(?,?,?)
      ON CONFLICT(user_id,content_id) DO UPDATE SET ${column}=excluded.${column}`).run(user.id, input.contentId, Number(input.value));
    return response({ ok: true });
  } catch (error) { return failure(error); }
}
