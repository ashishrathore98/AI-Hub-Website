import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Clock } from "lucide-react";
import { currentUser } from "@/server/auth";
import { getContent, listContent } from "@/server/catalog";
import { database } from "@/server/db";
import Shell from "@/components/shell";
import Markdown from "@/components/markdown";
import ResourceActions from "@/components/resource-actions";
import ResourceCard from "@/components/resource-card";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
type Props = { params: Promise<{ slug: string }> };
export async function generateMetadata({ params }: Props) {
  const content = getContent((await params).slug);
  return { title: content ? `${content.title} | AI HUB` : "Resource not found | AI HUB", description: content?.description };
}
export default async function Lesson({ params }: Props) {
  const user = await currentUser();
  const item = getContent((await params).slug, user?.role === "admin"); if (!item) notFound();
  const activity = user ? database().prepare("SELECT bookmarked,completed FROM activity WHERE user_id=? AND content_id=?").get(user.id, item.id) : null;
  const related = listContent(new URLSearchParams({ topic: item.topic })).items.filter(c => c.id !== item.id).slice(0, 3);
  return <Shell user={user} active={item.topic}><Link className="text-button back-link" href={`/?topic=${encodeURIComponent(item.topic)}`}><ArrowLeft size={15}/>Back to {item.topic.toLowerCase()}</Link>
    {item.status === "draft" && <div className="notice">Draft preview · Only administrators can read this resource.</div>}
    <article className="article"><header className="article-header"><div className="tag-row"><span className="dept-pill">{item.topic}</span><span className="tag">{item.level}</span><span className="tag">{item.department}</span></div><h1>{item.title}</h1><p className="article-description">{item.description}</p><div className="article-meta"><span><Clock size={14}/>{item.minutes} min read</span><span>Updated {new Date(item.updatedAt).toLocaleDateString("en-IN", { timeZone: "Asia/Kolkata", day: "numeric", month: "short", year: "numeric" })}</span><span>Version {item.version}</span>{user?.role === "admin" && <Link href={`/admin?edit=${item.id}`}>Edit resource →</Link>}</div></header>
      <ResourceActions id={item.id} template={item.template} signedIn={!!user} bookmarked={!!activity?.bookmarked} completed={!!activity?.completed}/>
      <Markdown body={item.body}/>
      {item.template && <section className="template-section"><span className="eyebrow">YOUR STARTING POINT</span><h2>Copyable template</h2><p>Replace the placeholders and adapt the instructions to your tools and data.</p><pre className="prompt-content">{item.template}</pre></section>}
      <div className="tag-row article-tags">{item.tags.map(t => <Link className="tag" href={`/?q=${encodeURIComponent(t)}`} key={t}>{t}</Link>)}</div>
    </article>
    {related.length > 0 && <><div className="section-heading"><h2>Keep exploring</h2></div><div className="prompt-grid">{related.map(c => <ResourceCard item={c} key={c.id}/>)}</div></>}
  </Shell>;
}
