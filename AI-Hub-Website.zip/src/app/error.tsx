"use client";
import Link from "next/link";
export default function ErrorPage({ reset }: { reset: () => void }) { return <main className="error-page"><h1>We couldn’t load this page</h1><p>Please try again. If the issue continues, contact the library administrator.</p><button className="primary-button" onClick={reset}>Try again</button><p><Link href="/">Return to the library</Link></p></main>; }
