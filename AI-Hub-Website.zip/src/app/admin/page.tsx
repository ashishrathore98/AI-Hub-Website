import { redirect } from "next/navigation";
import { currentUser } from "@/server/auth";
import { getContent, listContent, revisions } from "@/server/catalog";
import Shell from "@/components/shell";
import AdminEditor from "@/components/admin-editor";
export const dynamic = "force-dynamic";
export default async function Admin({ searchParams }: { searchParams: Promise<{ edit?: string }> }) {
  const user = await currentUser(); if (!user) redirect("/login?next=/admin");
  if (user.role !== "admin") return <Shell user={user} active="admin"><div className="notice error"><h1>Administrator access required</h1><p>Your account can browse resources and save progress. Ask the library administrator for editing access.</p></div></Shell>;
  const edit = (await searchParams).edit;
  const item = edit ? getContent(edit, true) : null;
  return <Shell user={user} active="admin"><AdminEditor initial={listContent(new URLSearchParams(), true)} selected={item} initialRevisions={item ? revisions(item.id) : []}/></Shell>;
}
