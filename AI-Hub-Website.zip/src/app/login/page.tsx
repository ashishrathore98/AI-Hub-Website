import { redirect } from "next/navigation";
import Shell from "@/components/shell";
import LoginForm from "@/components/login-form";
import { currentUser } from "@/server/auth";
export const dynamic = "force-dynamic";
export default async function Login({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  const { next: requested } = await searchParams;
  const next = requested && /^\/(?!\/)/.test(requested) && !/[\\\r\n]/.test(requested) ? requested : "/";
  const user = await currentUser(); if (user) redirect(next === "/login" || next.startsWith("/login?") ? "/" : next);
  return <Shell user={null} active="Sign in"><LoginForm registrationEnabled={process.env.ALLOW_REGISTRATION === "true"} next={next}/></Shell>;
}
