import { redirect } from "next/navigation";
import { currentUser } from "@/server/auth";
import Shell from "@/components/shell";
import PasswordForm from "@/components/password-form";
export const dynamic = "force-dynamic";
export default async function Account() {
  const user = await currentUser(); if (!user) redirect("/login?next=/account");
  return <Shell user={user} active="Account"><div className="page-title"><span className="eyebrow">YOUR ACCOUNT</span><h1>{user.name}</h1><p>{user.email} · {user.role === "admin" ? "Administrator" : "Learner"}</p></div><PasswordForm/></Shell>;
}
