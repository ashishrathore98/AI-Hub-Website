import Link from "next/link";
export default function NotFound() { return <main className="error-page"><span className="eyebrow">RESOURCE NOT FOUND</span><h1>This page isn’t available</h1><p>The resource may have moved or may no longer be published. Search the library to find another guide.</p><Link className="primary-button" href="/">Explore the library →</Link></main>; }
