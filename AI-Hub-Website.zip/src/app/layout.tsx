import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AI HUB | Your practical AI learning library",
  description: "Explore reusable prompts and practical guides to prompt engineering, AI agents, dashboards, and reliable automations.",
  icons: { icon: "/icon.svg" },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
