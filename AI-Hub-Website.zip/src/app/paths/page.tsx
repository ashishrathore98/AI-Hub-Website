import Link from "next/link";
import { currentUser } from "@/server/auth";
import { pathLessons } from "@/server/catalog";
import { database } from "@/server/db";
import { topics } from "@/lib/content";
import Shell from "@/components/shell";
export const dynamic = "force-dynamic";
export default async function Paths() {
  const user = await currentUser();
  const completed = new Set(user ? database().prepare("SELECT content_id FROM activity WHERE user_id=? AND completed=1").all(user.id).map(r => r.content_id) : []);
  return <Shell user={user} active="paths"><div className="page-title"><span className="eyebrow">A LITTLE STRUCTURE GOES A LONG WAY</span><h1>Choose your learning path</h1><p>Start with a foundation, try a practical example, and check what you’ve learned.</p></div>{!user && <div className="notice"><Link href="/login">Sign in</Link> to save your completion progress across devices.</div>}<div className="path-grid">{topics.filter(t => t !== "Prompts").map((topic, index) => {
    const lessons = pathLessons(topic);
    const done = lessons.filter(l => completed.has(l.id)).length;
    return <section className="path-card" key={topic}><span className="eyebrow">PATH {String(index + 1).padStart(2, "0")}</span><h2>{topic}</h2><p>{lessons.length} guides · {lessons.reduce((sum, l) => sum + l.minutes, 0)} min · {done} completed</p><progress value={done} max={lessons.length || 1} aria-label={`${topic} completion`}/><ol>{lessons.map(l => <li key={l.id}><Link href={`/learn/${l.slug}`}><span>{completed.has(l.id) ? "✓" : "○"}</span><div><b>{l.title}</b><small>{l.level} · {l.minutes} min</small></div><span>→</span></Link></li>)}</ol>{lessons.length === 0 && <p>New lessons will appear here when published.</p>}</section>;
  })}</div></Shell>;
}
