import "server-only";
import { createHash, randomBytes, randomUUID, scrypt, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { cookies } from "next/headers";
import { database } from "./db";
import { HttpError, text } from "./http";
import type { User } from "@/lib/content";

const derive = promisify(scrypt);
const cookieName = "stl_session";
const duration = 60 * 60 * 24 * 7;
const secureCookie = process.env.COOKIE_SECURE ? process.env.COOKIE_SECURE === "true" : process.env.NODE_ENV === "production";
const digest = (token: string) => createHash("sha256").update(token).digest("hex");
export async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const hash = await derive(password, salt, 64) as Buffer;
  return `${salt}:${hash.toString("hex")}`;
}
async function verify(password: string, encoded: string) {
  const [salt, hash] = encoded.split(":");
  const expected = Buffer.from(hash, "hex");
  const actual = await derive(password, salt, 64) as Buffer;
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}
export async function currentUser(): Promise<User | null> {
  const token = (await cookies()).get(cookieName)?.value;
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return null;
  const row = database().prepare(`SELECT u.id,u.name,u.email,u.role FROM sessions s
    JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?`).get(digest(token), Date.now()) as User | undefined;
  return row ? { ...row } : null;
}
export async function requireUser(admin = false) {
  const user = await currentUser();
  if (!user) throw new HttpError(401, "Please sign in to continue.");
  if (admin && user.role !== "admin") throw new HttpError(403, "Administrator access is required.");
  return user;
}
export async function startSession(userId: string) {
  const db = database();
  const cookieStore = await cookies();
  const old = cookieStore.get(cookieName)?.value;
  if (old) db.prepare("DELETE FROM sessions WHERE token_hash=?").run(digest(old));
  db.prepare("DELETE FROM sessions WHERE expires_at<=?").run(Date.now());
  const token = randomBytes(32).toString("hex");
  db.prepare("INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)").run(digest(token), userId, Date.now() + duration * 1000);
  cookieStore.set(cookieName, token, { httpOnly: true, secure: secureCookie, sameSite: "lax", path: "/", maxAge: duration });
}
export async function logout() {
  const store = await cookies(); const token = store.get(cookieName)?.value;
  if (token) database().prepare("DELETE FROM sessions WHERE token_hash=?").run(digest(token));
  store.set(cookieName, "", { httpOnly: true, secure: secureCookie, sameSite: "lax", path: "/", maxAge: 0 });
}
export function rateLimit(key: string, limit: number, windowMs: number) {
  const db = database(); const now = Date.now();
  db.prepare("DELETE FROM rate_limits WHERE reset_at<=?").run(now);
  const row = db.prepare(`INSERT INTO rate_limits(key,attempts,reset_at) VALUES(?,1,?)
    ON CONFLICT(key) DO UPDATE SET attempts=attempts+1 RETURNING attempts`).get(key, now + windowMs) as { attempts: number };
  if (row.attempts > limit) throw new HttpError(429, "Too many attempts. Please try again in 15 minutes.");
}
export async function authenticate(input: Record<string, unknown>, register: boolean) {
  const email = text(input.email, "Email", 3, 254).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new HttpError(400, "Enter a valid email address.");
  const password = input.password;
  if (typeof password !== "string" || password.length < 12 || password.length > 128)
    throw new HttpError(400, "Password must contain 12–128 characters.");
  // Email limits cannot be bypassed by changing IP headers.
  rateLimit(`auth:${digest(email)}`, 12, 15 * 60_000);
  const db = database();
  if (register) {
    if (process.env.ALLOW_REGISTRATION !== "true") throw new HttpError(403, "Self-registration is disabled. Ask your administrator for access.");
    const name = text(input.name, "Name", 2, 80);
    const hash = await hashPassword(password);
    const id = randomUUID();
    try { db.prepare("INSERT INTO users(id,name,email,password_hash,role) VALUES(?,?,?,?,'reader')").run(id, name, email, hash); }
    catch (error) {
      if ((error as Error).message.includes("UNIQUE")) throw new HttpError(409, "An account already exists for this email. Sign in instead.");
      throw error;
    }
    await startSession(id);
    return { id, name, email, role: "reader" } as User;
  }
  const row = db.prepare("SELECT id,name,email,role,password_hash FROM users WHERE email=?").get(email) as (User & { password_hash: string }) | undefined;
  // Do comparable password work even for an unknown account.
  const valid = await verify(password, row?.password_hash || `${"0".repeat(32)}:${"0".repeat(128)}`);
  if (!row || !valid) throw new HttpError(401, "Email or password is incorrect.");
  await startSession(row.id);
  return { id: row.id, name: row.name, email: row.email, role: row.role };
}
export async function changePassword(input: Record<string, unknown>) {
  const user = await requireUser();
  rateLimit(`password:${user.id}`, 8, 15 * 60_000);
  const row = database().prepare("SELECT password_hash FROM users WHERE id=?").get(user.id) as { password_hash: string };
  if (typeof input.currentPassword !== "string" || input.currentPassword.length > 128 || !await verify(input.currentPassword, row.password_hash)) throw new HttpError(400, "Current password is incorrect.");
  if (typeof input.newPassword !== "string" || input.newPassword.length < 12 || input.newPassword.length > 128) throw new HttpError(400, "New password must contain 12–128 characters.");
  const hash = await hashPassword(input.newPassword);
  const db = database();
  db.exec("BEGIN IMMEDIATE");
  try {
    db.prepare("UPDATE users SET password_hash=? WHERE id=?").run(hash, user.id);
    db.prepare("DELETE FROM sessions WHERE user_id=?").run(user.id);
    db.exec("COMMIT");
  } catch (error) { db.exec("ROLLBACK"); throw error; }
  await startSession(user.id);
}
