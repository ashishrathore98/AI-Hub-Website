import "server-only";
import { randomUUID } from "node:crypto";
import { database } from "./db";
import { HttpError, text } from "./http";
import { topics, levels, type Content, type ContentInput, type LibraryResult } from "@/lib/content";
import { departments } from "@/lib/data";
import { starterContent } from "@/lib/seed-content";

type Row = Record<string, unknown>;
function map(row: Row): Content {
  return {
    id: String(row.id), slug: String(row.slug), title: String(row.title), description: String(row.description),
    topic: row.topic as Content["topic"], department: String(row.department), level: row.level as Content["level"],
    tags: JSON.parse(String(row.tags)), body: String(row.body), template: String(row.template), minutes: Number(row.minutes),
    status: row.status as Content["status"], version: Number(row.version), createdAt: String(row.created_at), updatedAt: String(row.updated_at),
  };
}
export function initializeCatalog() {
  const db = database();
  if (db.prepare("SELECT value FROM app_meta WHERE key='starter_content_v1'").get()) return;
  db.exec("BEGIN IMMEDIATE");
  try {
    if (!db.prepare("SELECT value FROM app_meta WHERE key='starter_content_v1'").get()) {
      const now = new Date().toISOString();
      for (const item of starterContent) {
        db.prepare(`INSERT OR IGNORE INTO content(id,slug,title,description,topic,department,level,tags,body,template,minutes,status,created_at,updated_at)
          VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(randomUUID(), item.slug, item.title, item.description, item.topic, item.department, item.level, JSON.stringify(item.tags), item.body, item.template, item.minutes, item.status, now, now);
      }
      db.prepare("INSERT INTO app_meta(key,value) VALUES('starter_content_v1',?)").run(now);
    }
    db.exec("COMMIT");
  } catch (error) { db.exec("ROLLBACK"); throw error; }
}
export function listContent(params: URLSearchParams, admin = false): LibraryResult {
  initializeCatalog();
  const clauses = [admin ? "1=1" : "status='published'"]; const values: (string | number)[] = [];
  const q = (params.get("q") || "").trim().slice(0, 200);
  if (q) {
    clauses.push("(title || ' ' || description || ' ' || topic || ' ' || department || ' ' || level || ' ' || tags || ' ' || body || ' ' || template) LIKE ? ESCAPE '\\'");
    values.push(`%${q.replace(/[\\%_]/g, "\\$&")}%`);
  }
  for (const key of ["topic", "department", "level", "status"] as const) {
    const value = params.get(key);
    if (value && value !== "All" && value !== "All departments" && (key !== "status" || admin)) { clauses.push(`${key}=?`); values.push(value); }
  }
  const where = clauses.join(" AND ");
  const db = database();
  const total = (db.prepare(`SELECT count(*) AS total FROM content WHERE ${where}`).get(...values) as { total: number }).total;
  const pages = Math.max(1, Math.ceil(total / 12));
  const page = Math.min(pages, Math.max(1, Number(params.get("page")) || 1)) | 0;
  const items = db.prepare(`SELECT * FROM content WHERE ${where} ORDER BY updated_at DESC,title ASC LIMIT 12 OFFSET ?`).all(...values, (page - 1) * 12).map(map);
  return { items, total, page, pages };
}
export function getContent(identifier: string, admin = false) {
  initializeCatalog();
  const row = database().prepare(`SELECT * FROM content WHERE (slug=? OR id=?) ${admin ? "" : "AND status='published'"}`).get(identifier, identifier);
  return row ? map(row) : null;
}
export function validateContent(input: Record<string, unknown>): ContentInput {
  const title = text(input.title, "Title", 3, 140);
  const slug = text(input.slug, "URL slug", 3, 160);
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug)) throw new HttpError(400, "Use lowercase letters, numbers, and single hyphens in the URL slug.");
  if (!topics.includes(input.topic as never)) throw new HttpError(400, "Choose a valid topic.");
  if (!levels.includes(input.level as never)) throw new HttpError(400, "Choose a valid level.");
  if (!departments.includes(input.department as never)) throw new HttpError(400, "Choose a valid department.");
  if (input.status !== "draft" && input.status !== "published") throw new HttpError(400, "Choose draft or published.");
  if (!Array.isArray(input.tags) || input.tags.length > 10 || input.tags.some(t => typeof t !== "string" || t.trim().length < 1 || t.length > 40)) throw new HttpError(400, "Provide up to 10 tags, each 1–40 characters.");
  if (!Number.isInteger(input.minutes) || Number(input.minutes) < 1 || Number(input.minutes) > 180) throw new HttpError(400, "Reading time must be 1–180 minutes.");
  return { title, slug, description: text(input.description, "Description", 10, 350), topic: input.topic as ContentInput["topic"], department: String(input.department), level: input.level as ContentInput["level"], status: input.status, tags: [...new Set(input.tags.map(t => t.trim()))], body: text(input.body, "Lesson body", 30, 60_000), template: text(input.template ?? "", "Template", 0, 15_000), minutes: Number(input.minutes) };
}
export function saveContent(input: ContentInput, editorId: string, id?: string, expectedVersion?: number) {
  initializeCatalog(); const db = database(); db.exec("BEGIN IMMEDIATE");
  try {
    const existing = id ? getContent(id, true) : null;
    if (id && !existing) throw new HttpError(404, "Content was not found.");
    if (existing && existing.version !== expectedVersion) throw new HttpError(409, "Someone updated this content. Reload it before saving your changes.");
    const contentId = existing?.id || randomUUID(); const now = new Date().toISOString(); const version = (existing?.version || 0) + 1;
    if (existing) {
      // Save the previous full version so every edit can be inspected and restored.
      db.prepare("INSERT OR IGNORE INTO revisions(id,content_id,version,snapshot,editor_id,created_at) VALUES(?,?,?,?,?,?)").run(randomUUID(), contentId, existing.version, JSON.stringify(existing), editorId, now);
      db.prepare(`UPDATE content SET slug=?,title=?,description=?,topic=?,department=?,level=?,tags=?,body=?,template=?,minutes=?,status=?,version=?,updated_at=? WHERE id=?`).run(input.slug, input.title, input.description, input.topic, input.department, input.level, JSON.stringify(input.tags), input.body, input.template, input.minutes, input.status, version, now, contentId);
    } else {
      db.prepare(`INSERT INTO content(id,slug,title,description,topic,department,level,tags,body,template,minutes,status,version,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(contentId, input.slug, input.title, input.description, input.topic, input.department, input.level, JSON.stringify(input.tags), input.body, input.template, input.minutes, input.status, version, now, now);
    }
    db.exec("COMMIT"); return getContent(contentId, true)!;
  } catch (error) {
    db.exec("ROLLBACK");
    if ((error as Error).message.includes("UNIQUE constraint failed: content.slug")) throw new HttpError(409, "That URL slug is already in use.");
    throw error;
  }
}
export function revisions(id: string) {
  return database().prepare("SELECT version,snapshot,created_at AS savedAt FROM revisions WHERE content_id=? ORDER BY version DESC LIMIT 50").all(id).map(row => ({ version: row.version, savedAt: row.savedAt, content: JSON.parse(String(row.snapshot)) as Content }));
}
export function statistics() {
  initializeCatalog();
  return database().prepare("SELECT topic,count(*) AS count FROM content WHERE status='published' GROUP BY topic").all().map(row => ({ topic: String(row.topic), count: Number(row.count) }));
}
export function pathLessons(topic: string) {
  initializeCatalog();
  return database().prepare(`SELECT * FROM content WHERE status='published' AND topic=?
    ORDER BY CASE level WHEN 'Beginner' THEN 0 WHEN 'Intermediate' THEN 1 ELSE 2 END,created_at,title`).all(topic).map(map);
}
