import "server-only";
import { DatabaseSync } from "node:sqlite";
import { mkdirSync, readFileSync, readdirSync } from "node:fs";
import { dirname, join, resolve } from "node:path";

const globalDb = globalThis as unknown as { hubDb?: DatabaseSync };
export function database() {
  if (globalDb.hubDb) return globalDb.hubDb;
  const path = resolve(process.env.DATABASE_PATH || "data/hub.sqlite");
  mkdirSync(dirname(path), { recursive: true });
  const db = new DatabaseSync(path);
  db.exec("PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;");
  db.exec("CREATE TABLE IF NOT EXISTS migrations (name TEXT PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)");
  const directory = join(process.cwd(), "database/migrations");
  for (const name of readdirSync(directory).filter(n => n.endsWith(".sql")).sort()) {
    if (db.prepare("SELECT name FROM migrations WHERE name = ?").get(name)) continue;
    db.exec("BEGIN IMMEDIATE");
    try {
      // Check again after acquiring the writer lock for concurrent starts.
      if (!db.prepare("SELECT name FROM migrations WHERE name = ?").get(name)) {
        db.exec(readFileSync(join(directory, name), "utf8"));
        db.prepare("INSERT INTO migrations(name) VALUES (?)").run(name);
      }
      db.exec("COMMIT");
    } catch (error) { db.exec("ROLLBACK"); db.close(); throw error; }
  }
  globalDb.hubDb = db;
  return db;
}
