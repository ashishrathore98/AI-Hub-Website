export const topics = ["Prompts", "Prompt engineering", "Agents", "Dashboards", "Automations"] as const;
export const levels = ["Beginner", "Intermediate", "Advanced"] as const;
export type Topic = typeof topics[number];
export type Level = typeof levels[number];
export type User = { id: string; name: string; email: string; role: "admin" | "reader" };
export type Content = {
  id: string; slug: string; title: string; description: string;
  topic: Topic; department: string; level: Level; tags: string[];
  body: string; template: string; minutes: number; status: "draft" | "published";
  version: number; createdAt: string; updatedAt: string;
};
export type ContentInput = Omit<Content, "id" | "createdAt" | "updatedAt" | "version">;
export type LibraryResult = { items: Content[]; total: number; page: number; pages: number };
export type Activity = { bookmarks: string[]; completed: string[] };
