export async function api<T>(path: string, method = "GET", body?: unknown, signal?: AbortSignal): Promise<T> {
  const res = await fetch(path, { method, headers: body ? { "Content-Type": "application/json" } : undefined, body: body ? JSON.stringify(body) : undefined, signal, cache: "no-store" });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Something went wrong. Try again.");
  return data as T;
}
