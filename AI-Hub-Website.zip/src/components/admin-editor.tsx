"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { Plus, Save, Search } from "lucide-react";
import { topics, levels, type Content, type ContentInput, type LibraryResult } from "@/lib/content";
import { departments } from "@/lib/data";
import { api } from "@/lib/api";
import Markdown from "./markdown";
type Revision = { version: unknown; savedAt: unknown; content: Content };
const empty: ContentInput = { title: "", slug: "", description: "", topic: "Prompt engineering", department: "All departments", level: "Beginner", tags: [], body: "", template: "", minutes: 5, status: "draft" };
export default function AdminEditor({ initial, selected, initialRevisions }: { initial: LibraryResult; selected: Content | null; initialRevisions: Revision[] }) {
  const [list, setList] = useState(initial); const [editing, setEditing] = useState<Content | null>(selected);
  const [form, setForm] = useState<ContentInput>(selected || { ...empty });
  const [tagText, setTagText] = useState(selected?.tags.join(", ") || "");
  const [history, setHistory] = useState(initialRevisions); const [q, setQ] = useState("");
  const [page, setPage] = useState(1); const [status, setStatus] = useState("All");
  const [busy, setBusy] = useState(false); const [listBusy, setListBusy] = useState(false); const [message, setMessage] = useState("");
  const [error, setError] = useState(""); const [preview, setPreview] = useState(false); const [dirty, setDirty] = useState(false); const [refresh, setRefresh] = useState(0);
  useEffect(() => {
    const guard = (e: BeforeUnloadEvent) => { if (dirty) { e.preventDefault(); e.returnValue = ""; } };
    const guardLink = (e: MouseEvent) => {
      const link = (e.target as Element).closest?.("a[href]") as HTMLAnchorElement | null;
      if (!dirty || !link || link.target === "_blank" || e.button !== 0 || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey || link.getAttribute("href")?.startsWith("#")) return;
      if (!window.confirm("Discard unsaved changes to this resource?")) { e.preventDefault(); e.stopPropagation(); }
    };
    window.addEventListener("beforeunload", guard); document.addEventListener("click", guardLink, true);
    return () => { window.removeEventListener("beforeunload", guard); document.removeEventListener("click", guardLink, true); };
  }, [dirty]);
  useEffect(() => {
    const controller = new AbortController(); setListBusy(true);
    const timer = setTimeout(() => {
      api<LibraryResult>(`/api/content?${new URLSearchParams({ admin: "true", q, page: String(page), status })}`, "GET", undefined, controller.signal)
        .then(setList).catch(e => { if (!controller.signal.aborted) setError(e.message); }).finally(() => { if (!controller.signal.aborted) setListBusy(false); });
    }, 200);
    return () => { clearTimeout(timer); controller.abort(); };
  }, [q, page, status, refresh]);
  function patch<K extends keyof ContentInput>(key: K, value: ContentInput[K]) { setForm(old => ({ ...old, [key]: value })); setDirty(true); }
  function canLeave() { return !dirty || window.confirm("Discard unsaved changes to this resource?"); }
  async function open(id: string) {
    if (!canLeave()) return; setBusy(true); setError(""); setMessage("");
    try {
      const data = await api<{ content: Content; revisions: Revision[] }>(`/api/content/${id}?admin=true`);
      setEditing(data.content); setForm(data.content); setTagText(data.content.tags.join(", ")); setHistory(data.revisions); setDirty(false); setPreview(false);
    } catch (e) { setError((e as Error).message); } finally { setBusy(false); }
  }
  function create() {
    if (!canLeave()) return;
    setEditing(null); setForm({ ...empty }); setTagText(""); setHistory([]); setDirty(false); setMessage(""); setError(""); setPreview(false);
  }
  async function save(event: React.FormEvent) {
    event.preventDefault(); setBusy(true); setError(""); setMessage("");
    try {
      const payload = { ...form, tags: tagText.split(",").map(t => t.trim()).filter(Boolean), version: editing?.version };
      const data = await api<{ content: Content }>(editing ? `/api/content/${editing.id}` : "/api/content", editing ? "PUT" : "POST", payload);
      setEditing(data.content); setForm(data.content); setTagText(data.content.tags.join(", ")); setDirty(false);
      setMessage(data.content.status === "published" ? "Published. Readers can now see this version." : "Draft saved. It is visible only to administrators.");
      setRefresh(v => v + 1);
      const detail = await api<{ revisions: Revision[] }>(`/api/content/${data.content.id}?admin=true`); setHistory(detail.revisions);
    } catch (e) { setError((e as Error).message); } finally { setBusy(false); }
  }
  return <><div className="page-title-row"><div><span className="eyebrow">KEEP YOUR LIBRARY GROWING</span><h1>Content studio</h1><p>Create, update, and publish resources without changing code.</p></div><button className="primary-button" onClick={create} disabled={busy}><Plus size={17}/>New resource</button></div>
    <div className="studio-layout"><aside className="studio-list"><div className="search-field"><Search size={16}/><input value={q} placeholder="Find a resource..." aria-label="Search content to edit" onChange={e => { setQ(e.target.value); setPage(1); }}/></div><label className="studio-status">Publication status<select value={status} onChange={e => { setStatus(e.target.value); setPage(1); }}><option value="All">All content</option><option value="draft">Drafts</option><option value="published">Published</option></select></label><p className="results-info" aria-live="polite">{listBusy ? "Loading…" : `${list.total} resources`}</p><div className="studio-items">{list.items.map(item => <button disabled={busy} className={editing?.id === item.id ? "studio-item selected" : "studio-item"} key={item.id} onClick={() => open(item.id)}><b>{item.title}</b><small>{item.topic} · <span className={`status-${item.status}`}>{item.status}</span> · v{item.version}</small></button>)}{!list.items.length && !listBusy && <p>No resources match these filters.</p>}</div><div className="pagination"><button disabled={listBusy || page <= 1} className="outline-button" onClick={() => setPage(list.page - 1)}>←</button><span>{list.page} / {list.pages}</span><button disabled={listBusy || list.page >= list.pages} className="outline-button" onClick={() => setPage(list.page + 1)}>→</button></div></aside>
    <section className="studio-editor"><div className="editor-heading"><h2>{editing ? "Edit resource" : "Create a resource"}</h2><span>{dirty ? "Unsaved changes" : editing ? `Version ${editing.version}` : "New draft"}</span></div><form className="form-stack" onSubmit={save}><fieldset disabled={busy}>
      <label>Title<input required minLength={3} maxLength={140} value={form.title} onChange={e => { const title = e.target.value; setForm(old => ({ ...old, title, ...(!editing && (!old.slug || old.slug === old.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "")) ? { slug: title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") } : {}) })); setDirty(true); }}/></label>
      <label>URL slug<input required minLength={3} maxLength={160} pattern="[a-z0-9]+(-[a-z0-9]+)*" value={form.slug} onChange={e => patch("slug", e.target.value)}/><small>Published address: /learn/{form.slug || "your-resource"}. Keep this stable when updating shared resources.</small></label>
      <label>Short description<textarea required minLength={10} maxLength={350} rows={2} value={form.description} onChange={e => patch("description", e.target.value)}/></label>
      <div className="form-grid"><label>Topic<select value={form.topic} onChange={e => patch("topic", e.target.value as ContentInput["topic"])}>{topics.map(t => <option key={t}>{t}</option>)}</select></label><label>Department<select value={form.department} onChange={e => patch("department", e.target.value)}>{departments.map(d => <option key={d}>{d}</option>)}</select></label><label>Level<select value={form.level} onChange={e => patch("level", e.target.value as ContentInput["level"])}>{levels.map(l => <option key={l}>{l}</option>)}</select></label><label>Reading time (minutes)<input type="number" min={1} max={180} required value={form.minutes} onChange={e => patch("minutes", Number(e.target.value))}/></label></div>
      <label>Tags, separated by commas<input maxLength={410} value={tagText} onChange={e => { setTagText(e.target.value); setDirty(true); }}/><small>Up to 10 tags, each 40 characters or fewer.</small></label>
      <div className="editor-heading"><h3>Lesson content</h3><button type="button" className="text-button" onClick={() => setPreview(!preview)}>{preview ? "Write" : "Preview"}</button></div>
      {preview ? <div className="editor-preview"><Markdown body={form.body}/>{!form.body && <p>Write a lesson to preview it here.</p>}</div> : <label className="body-label">Body<textarea required minLength={30} maxLength={60000} rows={20} className="code-input" value={form.body} onChange={e => patch("body", e.target.value)}/><small>Supports headings (#, ##, ###), paragraphs, numbered lists, bullet lists, **bold**, `inline code`, and fenced code blocks. HTML is displayed as text.</small></label>}
      <label>Copyable prompt or template (optional)<textarea rows={6} maxLength={15000} className="code-input" value={form.template} onChange={e => patch("template", e.target.value)}/></label>
      <label>Publication status<select value={form.status} onChange={e => patch("status", e.target.value as ContentInput["status"])}><option value="draft">Draft · administrators only</option><option value="published">Published · visible to everyone</option></select><small>To remove a resource from the public library, save it as a draft.</small></label>
      <div className="editor-actions"><button className="primary-button" disabled={busy}><Save size={16}/>{busy ? "Saving…" : form.status === "published" ? "Save and publish" : "Save draft"}</button>{editing && <Link className="outline-button" href={`/learn/${editing.slug}`} target="_blank">Open resource ↗</Link>}</div>
    </fieldset></form>{message && <div className="notice success" role="status">{message}</div>}{error && <div className="notice error" role="alert">{error}</div>}
    {history.length > 0 && <details className="revision-history"><summary>Previous versions ({history.length})</summary><p>Load an earlier version into the editor, review it, then save to create a new version.</p>{history.map(r => <div className="revision-row" key={String(r.version)}><span>Version {String(r.version)}</span><button disabled={busy} className="text-button" onClick={() => { if (!canLeave()) return; setForm({ ...r.content }); setTagText(r.content.tags.join(", ")); setDirty(true); setMessage(`Version ${String(r.version)} loaded. Review and save to restore it.`); }}>Load this version</button></div>)}</details>}
    </section></div></>;
}
