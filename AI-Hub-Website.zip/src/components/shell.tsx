"use client";
import Link from "next/link";
import { useState } from "react";
import { BookOpen, Bot, BarChart3, GraduationCap, Menu, Search, Settings, Sparkles, WandSparkles, Workflow, X } from "lucide-react";
import type { User } from "@/lib/content";
import { api } from "@/lib/api";
const navigation = [
  { label: "All resources", href: "/", icon: BookOpen, topic: "All" },
  { label: "Prompt library", href: "/?topic=Prompts", icon: Search, topic: "Prompts" },
  { label: "Prompt engineering", href: "/?topic=Prompt+engineering", icon: WandSparkles, topic: "Prompt engineering" },
  { label: "Agent Academy", href: "/?topic=Agents", icon: Bot, topic: "Agents" },
  { label: "Dashboard School", href: "/?topic=Dashboards", icon: BarChart3, topic: "Dashboards" },
  { label: "Automation Lab", href: "/?topic=Automations", icon: Workflow, topic: "Automations" },
];
export default function Shell({ children, user, active = "All" }: { children: React.ReactNode; user: User | null; active?: string }) {
  const [open, setOpen] = useState(false); const [error, setError] = useState("");
  async function logout() { try { await api("/api/auth/logout", "POST", {}); window.location.assign("/"); } catch (e) { setError((e as Error).message); } }
  return <div className="app-shell">
    <aside className={`sidebar ${open ? "sidebar-open" : ""}`}>
      <Link className="brand" href="/"><div className="brand-mark"><Sparkles size={22}/></div><div><strong>AI HUB</strong><span>LEARN · BUILD · GROW</span></div></Link>
      <button className="icon-button mobile-close" aria-label="Close navigation" onClick={() => setOpen(false)}><X size={20}/></button>
      <div className="sidebar-label">KNOWLEDGE LIBRARY</div>
      <nav className="nav-list" aria-label="Main navigation">{navigation.map(n => <Link className={`nav-item ${active === n.topic ? "active" : ""}`} key={n.topic} href={n.href} onClick={() => setOpen(false)}><n.icon size={19}/>{n.label}</Link>)}
        <Link className={`nav-item ${active === "paths" ? "active" : ""}`} href="/paths"><GraduationCap size={19}/>Learning paths</Link>
        <Link className={`nav-item ${active === "saved" ? "active" : ""}`} href="/saved"><BookOpen size={19}/>My saved resources</Link>
        {user?.role === "admin" && <Link className={`nav-item ${active === "admin" ? "active" : ""}`} href="/admin"><Settings size={19}/>Manage content</Link>}
      </nav>
      <div className="sidebar-bottom"><div className="note-panel"><div className="note-icon"><GraduationCap size={19}/></div><b>Start small. Build your skills.</b><p>Practical guides, reusable prompts, and a clear path from your first question to a reliable workflow.</p><Link href="/paths">Find your learning path →</Link></div><div className="sidebar-foot"><span className="online-indicator"/>Your AI learning library<span className="version">v2.0</span></div></div>
    </aside>
    {open && <button className="scrim" aria-label="Close navigation" onClick={() => setOpen(false)}/>}
    <main className="main"><header className="topbar"><div className="breadcrumb"><button className="mobile-menu icon-button" aria-label="Open navigation" onClick={() => setOpen(true)}><Menu size={21}/></button><Link href="/">Library</Link><span>/</span><strong>{active === "All" ? "Explore" : active}</strong></div><div className="top-right">{user ? <><Link className="user-name" href="/account">{user.name}</Link><button className="outline-button compact" onClick={logout}>Sign out</button></> : <Link className="primary-button compact" href="/login">Sign in</Link>}</div></header>
      {error && <div className="notice error" role="alert">{error}</div>}
      <div className="content">{children}</div>
      <footer className="footer"><span>AI HUB · Learn at your own pace</span><span>Guides and templates · Verify results in your chosen tools</span></footer>
    </main>
  </div>;
}
