import Link from "next/link";
import { ArrowRight, Clock } from "lucide-react";
import type { Content } from "@/lib/content";
export default function ResourceCard({ item, complete = false }: { item: Content; complete?: boolean }) {
  return <article className="prompt-card resource-card"><div className="prompt-card-top"><span className="dept-pill">{item.topic}</span><span className="difficulty">{complete ? "✓ Completed" : item.level}</span></div><h3><Link href={`/learn/${item.slug}`}>{item.title}</Link></h3><p>{item.description}</p><div className="tag-row">{item.tags.map(tag => <span className="tag" key={tag}>{tag}</span>)}</div><div className="prompt-card-bottom"><Link className="view-prompt" href={`/learn/${item.slug}`}>{item.topic === "Prompts" ? "View prompt" : "Read guide"}<ArrowRight size={15}/></Link><span className="reading-time"><Clock size={13}/>{item.minutes} min</span></div></article>;
}
