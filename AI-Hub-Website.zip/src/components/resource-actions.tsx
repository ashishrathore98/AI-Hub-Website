"use client";
import { useState } from "react";
import Link from "next/link";
import { Bookmark, Check, Copy } from "lucide-react";
import { api } from "@/lib/api";
export default function ResourceActions({ id, template, signedIn, bookmarked, completed }: { id: string; template: string; signedIn: boolean; bookmarked: boolean; completed: boolean }) {
  const [saved, setSaved] = useState(bookmarked); const [done, setDone] = useState(completed);
  const [busy, setBusy] = useState(false); const [message, setMessage] = useState("");
  async function toggle(field: "bookmarked" | "completed") {
    setBusy(true); setMessage("");
    const value = !(field === "bookmarked" ? saved : done);
    try { await api("/api/activity", "PUT", { contentId: id, field, value }); if (field === "bookmarked") setSaved(value); else setDone(value); }
    catch (e) { setMessage((e as Error).message); } finally { setBusy(false); }
  }
  async function copy() {
    try { await navigator.clipboard.writeText(template); setMessage("Template copied. Replace the placeholders before using it."); }
    catch { setMessage("Copy is unavailable. Select the template text below and copy it manually."); }
  }
  return <div className="resource-actions">{template && <button className="primary-button" onClick={copy}><Copy size={16}/>Copy template</button>}{signedIn ? <><button disabled={busy} className="outline-button" onClick={() => toggle("bookmarked")}><Bookmark size={16} fill={saved ? "currentColor" : "none"}/>{saved ? "Saved" : "Save resource"}</button><button disabled={busy} className={done ? "outline-button completed-button" : "outline-button"} onClick={() => toggle("completed")}><Check size={16}/>{done ? "Completed" : "Mark complete"}</button></> : <Link className="outline-button" href="/login">Sign in to save your progress</Link>}<p className="action-message" role="status">{message}</p></div>;
}
