import Link from "next/link";

const rules = [
  { name: "Role", question: "Who should the AI act as?", tip: "Choose a relevant perspective or area of expertise.", example: "Act as a sales analyst." },
  { name: "Context", question: "What does the AI need to know?", tip: "Explain the situation, audience, and source material.", example: "I am a branch manager reviewing last month's sales. Use the attached approved sales report." },
  { name: "Task", question: "What should the AI do?", tip: "Start with a clear action and describe the result you need.", example: "Summarize sales performance and identify the three largest changes compared with the previous month." },
  { name: "Format", question: "How should the answer look?", tip: "Specify a structure, length, and tone that suit your audience.", example: "Write a brief summary, a table of key figures, and three bullet points in plain language." },
  { name: "Constraints", question: "What limits must it follow?", tip: "Set boundaries for sources, assumptions, and missing information.", example: "Use only the supplied figures, cite source rows, and flag missing data. Do not invent numbers or causes." },
];

export default function PromptRules({ showBuilderLink = true }: { showBuilderLink?: boolean }) {
  return <section className="prompt-rules" id="prompt-rules" aria-labelledby="prompt-rules-title">
    <div className="section-heading"><div><span className="eyebrow">PROMPT WRITING BASICS</span><h2 id="prompt-rules-title">5 golden rules for better prompts</h2><p>Tell the AI who to be, what to know, what to do, how to respond, and which limits to follow.</p></div></div>
    <ol className="golden-rules-grid">{rules.map((rule, index) => <li className="golden-rule" key={rule.name}>
      <span className="golden-rule-number" aria-hidden="true">{index + 1}</span><h3>{rule.name}</h3><strong>{rule.question}</strong><p>{rule.tip}</p><blockquote><span>Example</span>{rule.example}</blockquote>
    </li>)}</ol>
    <details className="prompt-rules-example"><summary>See how the five parts work together</summary><p>A vague prompt: <q>Analyze my sales.</q></p><p>A clearer prompt gives the AI specific instructions:</p><pre>{rules.map(rule => `${rule.name}: ${rule.example}`).join("\n\n")}</pre><p>Replace the example details with your own. Attach the report before running the prompt.</p></details>
    <div className="prompt-rules-practice"><div><h3>Write, check, refine</h3><p>Start with one clear goal. Separate source material from instructions, share only data you are allowed to use, and ask for clarification when key details are missing. Check the answer against your sources, then refine your prompt.</p></div>{showBuilderLink && <Link className="outline-button" href="/builder">Try the prompt builder</Link>}</div>
  </section>;
}
