"use client";
import { useState } from "react";
import Link from "next/link";
import { api } from "@/lib/api";
export default function LoginForm({ registrationEnabled, next }: { registrationEnabled: boolean; next: string }) {
  const [register, setRegister] = useState(false); const [busy, setBusy] = useState(false); const [error, setError] = useState("");
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError(""); const data = new FormData(event.currentTarget);
    try { await api(`/api/auth/${register ? "register" : "login"}`, "POST", Object.fromEntries(data)); window.location.assign(next); }
    catch (e) { setError((e as Error).message); setBusy(false); }
  }
  return <div className="auth-card"><span className="eyebrow">YOUR LEARNING WORKSPACE</span><h1>{register ? "Create your account" : "Welcome back"}</h1><p>{register ? "Save useful resources and keep track of what you’ve learned." : "Sign in to continue learning or manage your library."}</p><form className="form-stack" onSubmit={submit}>{register && <label>Your name<input name="name" required minLength={2} maxLength={80} autoComplete="name"/></label>}<label>Email address<input type="email" name="email" required maxLength={254} autoComplete="email"/></label><label>Password<input type="password" name="password" required minLength={12} maxLength={128} autoComplete={register ? "new-password" : "current-password"}/><small>Use 12–128 characters.</small></label>{error && <div className="notice error" role="alert">{error}</div>}<button className="primary-button" disabled={busy}>{busy ? "Please wait…" : register ? "Create account" : "Sign in"}</button></form>{registrationEnabled && <button className="text-button auth-toggle" onClick={() => { setRegister(!register); setError(""); }}>{register ? "Already have an account? Sign in" : "New here? Create an account"}</button>}<Link className="text-button auth-toggle" href="/">Browse the library without signing in →</Link><p className="auth-help">Need access or a password reset? Contact the library administrator.</p></div>;
}
