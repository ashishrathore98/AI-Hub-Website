// A deliberately small, text-only Markdown renderer. Raw HTML is never interpreted.
import { Fragment } from "react";
function inline(text: string) {
  return text.split(/(\*\*[^*]+\*\*|`[^`]+`)/g).map((part, i) => part.startsWith("**") ? <strong key={i}>{part.slice(2, -2)}</strong> : part.startsWith("`") ? <code key={i}>{part.slice(1, -1)}</code> : <Fragment key={i}>{part}</Fragment>);
}
export default function Markdown({ body }: { body: string }) {
  const blocks = body.replace(/\r/g, "").split(/(```[^\n]*\n[\s\S]*?```)/g);
  return <div className="prose">{blocks.map((block, index) => {
    if (block.startsWith("```")) return <pre key={index}><code>{block.replace(/^```[^\n]*\n/, "").replace(/```$/, "").trimEnd()}</code></pre>;
    return <Fragment key={index}>{block.trim().split(/\n\s*\n/).filter(Boolean).map((paragraph, i) => {
      if (/^### /.test(paragraph)) return <h3 key={i}>{inline(paragraph.slice(4))}</h3>;
      if (/^## /.test(paragraph)) return <h2 key={i}>{inline(paragraph.slice(3))}</h2>;
      if (/^# /.test(paragraph)) return <h2 key={i}>{inline(paragraph.slice(2))}</h2>;
      const lines = paragraph.split("\n");
      if (lines.every(l => /^\d+\. /.test(l))) return <ol key={i}>{lines.map((l, j) => <li key={j}>{inline(l.replace(/^\d+\. /, ""))}</li>)}</ol>;
      if (lines.every(l => /^[-*] /.test(l))) return <ul key={i}>{lines.map((l, j) => <li key={j}>{inline(l.slice(2))}</li>)}</ul>;
      return <p key={i}>{inline(paragraph)}</p>;
    })}</Fragment>;
  })}</div>;
}
