"use client";
import { useState } from "react";
import { api } from "@/lib/api";
export default function PasswordForm() {
  const [busy, setBusy] = useState(false); const [message, setMessage] = useState(""); const [error, setError] = useState("");
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); const form = e.currentTarget; const data = new FormData(form); setBusy(true); setMessage(""); setError("");
    if (data.get("newPassword") !== data.get("confirmPassword")) { setError("The new passwords do not match."); setBusy(false); return; }
    try { await api("/api/auth/password", "POST", Object.fromEntries(data)); setMessage("Password changed. Your other sessions have been signed out."); form.reset(); }
    catch (e) { setError((e as Error).message); } finally { setBusy(false); }
  }
  return <form className="auth-card form-stack account-form" onSubmit={submit}><h2>Change password</h2><label>Current password<input type="password" name="currentPassword" required autoComplete="current-password" maxLength={128}/></label><label>New password<input type="password" name="newPassword" required minLength={12} maxLength={128} autoComplete="new-password"/></label><label>Confirm new password<input type="password" name="confirmPassword" required minLength={12} maxLength={128} autoComplete="new-password"/></label><button className="primary-button" disabled={busy}>{busy ? "Updating…" : "Update password"}</button>{error && <div className="notice error" role="alert">{error}</div>}{message && <div className="notice success" role="status">{message}</div>}</form>;
}
