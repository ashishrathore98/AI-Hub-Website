"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { ArrowRight, BookOpen, Search, WandSparkles } from "lucide-react";
import Shell from "./shell";
import ResourceCard from "./resource-card";
import PromptRules from "./prompt-rules";
import { topics, levels, type LibraryResult, type User } from "@/lib/content";
import { departments } from "@/lib/data";
import { api } from "@/lib/api";
export default function Hub({ initial, stats, user, initialQuery }: { initial: LibraryResult; stats: { topic: string; count: number }[]; user: User | null; initialQuery: string }) {
  const initialParams = new URLSearchParams(initialQuery);
  const [q, setQ] = useState(initialParams.get("q") || ""); const [topic, setTopic] = useState(initialParams.get("topic") || "All");
  const [department, setDepartment] = useState(initialParams.get("department") || "All departments"); const [level, setLevel] = useState(initialParams.get("level") || "All");
  const [page, setPage] = useState(initial.page); const [result, setResult] = useState(initial);
  const [loading, setLoading] = useState(false); const [error, setError] = useState(""); const [retry, setRetry] = useState(0);
  const latest = useRef(0);
  useEffect(() => {
    const p = new URLSearchParams(initialQuery);
    setQ(p.get("q") || ""); setTopic(p.get("topic") || "All"); setDepartment(p.get("department") || "All departments"); setLevel(p.get("level") || "All"); setPage(initial.page); setResult(initial);
  }, [initialQuery, initial]);
  useEffect(() => {
    const request = ++latest.current; const controller = new AbortController();
    setLoading(true); setError("");
    const timer = setTimeout(async () => {
      const params = new URLSearchParams();
      if (q) params.set("q", q); if (topic !== "All") params.set("topic", topic); if (department !== "All departments") params.set("department", department); if (level !== "All") params.set("level", level); if (page > 1) params.set("page", String(page));
      try {
        const data = await api<LibraryResult>(`/api/content?${params}`, "GET", undefined, controller.signal);
        if (request !== latest.current) return;
        setResult(data);
        window.history.replaceState(null, "", params.size ? `/?${params}` : "/");
      } catch (e) { if (!controller.signal.aborted && request === latest.current) setError((e as Error).message); }
      finally { if (request === latest.current) setLoading(false); }
    }, 250);
    return () => { clearTimeout(timer); controller.abort(); };
  }, [q, topic, department, level, page, retry]);
  function selectTopic(value: string) { setTopic(value); setPage(1); }
  const total = stats.reduce((sum, s) => sum + s.count, 0);
  return <Shell user={user} active={topic}>
    <section className="hero library-hero"><div className="hero-content"><div className="eyebrow light"><BookOpen size={14}/> YOUR PRACTICAL AI LIBRARY</div><h1>Learn the skills.<br/><em>Build what’s next.</em></h1><p>Discover useful prompts and learn to build agents, dashboards, and automations—one practical guide at a time.</p><div className="hero-actions"><Link className="white-button" href="/paths">Start learning<ArrowRight size={17}/></Link><Link className="hero-secondary" href="/builder"><WandSparkles size={17}/> Build a prompt</Link></div></div><div className="hero-art library-hero-art" aria-hidden="true"><div className="orb orb-a"/><div className="orb orb-b"/><div className="hero-monogram">AI<span>Ideas into practice</span></div><div className="hero-grid"/></div></section>
    <div className="prompt-guide-link"><a className="text-button" href="#prompt-rules">New to prompting? Learn the 5 golden rules ↓</a></div>
    <div className="topic-strip"><button className={topic === "All" ? "topic-button selected" : "topic-button"} onClick={() => selectTopic("All")}>All resources <span>{total}</span></button>{topics.map(t => <button className={topic === t ? "topic-button selected" : "topic-button"} key={t} onClick={() => selectTopic(t)}>{t}<span>{stats.find(s => s.topic === t)?.count || 0}</span></button>)}</div>
    <div className="section-heading"><div><span className="eyebrow">EXPLORE THE COLLECTION</span><h2>{topic === "All" ? "Find your next useful idea" : topic}</h2><p>Search by task, skill, department, or keyword.</p></div></div>
    <div className="library-toolbar"><div className="search-field"><Search size={19}/><input aria-label="Search library" placeholder="Search prompts, agents, dashboards..." value={q} onChange={e => { setQ(e.target.value); setPage(1); }}/></div><select className="library-select" aria-label="Department" value={department} onChange={e => { setDepartment(e.target.value); setPage(1); }}>{departments.map(d => <option key={d}>{d}</option>)}</select><select className="library-select" aria-label="Difficulty" value={level} onChange={e => { setLevel(e.target.value); setPage(1); }}><option value="All">All levels</option>{levels.map(l => <option key={l}>{l}</option>)}</select></div>
    <div className="results-info" aria-live="polite">{loading ? "Searching the library…" : `${result.total} resources found`}</div>
    {error ? <div className="notice error" role="alert">{error} <button onClick={() => setRetry(retry + 1)}>Try again</button></div> : <div className="prompt-grid" aria-busy={loading}>{result.items.map(item => <ResourceCard key={item.id} item={item}/>)}</div>}
    {!error && !loading && result.items.length === 0 && <div className="empty"><Search size={28}/><h3>No resources found</h3><p>Try fewer keywords or another topic.</p><button className="outline-button" onClick={() => { setQ(""); setTopic("All"); setDepartment("All departments"); setLevel("All"); setPage(1); }}>Clear filters</button></div>}
    {result.pages > 1 && <nav className="pagination" aria-label="Library pages"><button className="outline-button" disabled={loading || result.page <= 1} onClick={() => setPage(result.page - 1)}>Previous</button><span>Page {result.page} of {result.pages}</span><button className="outline-button" disabled={loading || result.page >= result.pages} onClick={() => setPage(result.page + 1)}>Next</button></nav>}
    <div className="workflow-banner"><div><span className="eyebrow">MAKE IT YOUR OWN</span><h3>A starting point for your next project</h3><p>Adapt templates to your data and tools. Follow a guide, test the results, and return whenever you need a reference.</p></div><Link className="outline-button" href="/paths">Explore learning paths<ArrowRight size={16}/></Link></div>
    <PromptRules/>
  </Shell>;
}
