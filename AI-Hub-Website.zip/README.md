# AI HUB

A full-stack learning library for reusable prompts, prompt engineering, agents, dashboards, and automations. Readers can browse without an account. Signed-in learners can bookmark resources and track lesson completion. Administrators can manage content in the website.

## Run locally

Requires **Node.js 24 LTS** (the application uses Node's built-in SQLite driver).

From this directory in PowerShell:

```powershell
npm.cmd ci
Copy-Item .env.example .env.local
npm.cmd run admin:create
npm.cmd run dev
```

Do not overwrite an existing `.env.local`; merge settings instead. The admin command asks for your email and name, then prints a randomly generated password once. Store it securely, sign in at **http://localhost:3000/login**, and change it from your account page. Open **http://localhost:3000/admin** to manage content.

Use `npm` instead of `npm.cmd` on macOS/Linux. `npm.cmd` avoids the Windows PowerShell script-execution-policy issue.

The database and schema are created automatically. On the first library request, 15 prompt templates and 8 practical guides are inserted once. Subsequent starts preserve edits and publication status. `src/lib/data.ts` is now seed material, not the live content store; editing it does not overwrite database content.

## Add or update content

1. Sign in with an administrator account and open **Manage content**.
2. Select an existing resource or choose **New resource**.
3. Set its title, stable URL slug, description, topic, department, level, tags, and reading time.
4. Write the lesson and optionally add a copyable template. Preview the lesson before saving.
5. Save as **Draft** while working; select **Published** and save when ready to share.

Every resource has a shareable `/learn/your-slug` address. Keep the slug stable after sharing it. Drafts are visible only to administrators, including on direct URLs and API requests. Change published content back to draft to remove it from public access. Existing readers may retain material they already viewed or copied.

Previous versions can be loaded into the editor, reviewed, and saved as a new version. Simultaneous edits are detected: a stale version receives a conflict instead of overwriting another editor's work. The UI warns about leaving an unsaved resource.

The text editor supports headings, paragraphs, numbered lists, bullet lists, bold text, inline code, and fenced code blocks. Raw HTML is displayed as text. Images, arbitrary HTML, and Markdown links are not supported by this first editor.

## Reader accounts

Set `ALLOW_REGISTRATION=true` to allow learners to create accounts. Registration always creates a reader, regardless of submitted role fields. Set it to `false` for invitation-only use, then create reader accounts locally:

```powershell
npm.cmd run admin:create -- --reader
```

To reset a password for an existing account:

```powershell
npm.cmd run admin:create -- --reset
```

Resetting a password revokes all sessions and preserves the existing account's role. The CLI does not silently promote an existing reader to administrator. Create a separate admin account if needed. Logged-in users can change their own password at `/account`.

There is no email verification, email password-reset delivery, SSO, or user-management dashboard in this version. The local CLI is the recovery mechanism. Do not treat reader email addresses as verified identities.

## Architecture

```text
Next.js pages and React components
             |
Route handlers: validation, origin checks, authorization
             |
Server services: authentication, content lifecycle, search
             |
SQLite repository and versioned SQL migrations
```

- `src/app/`: pages and HTTP API entry points.
- `src/components/`: library, article renderer, account forms, and content studio.
- `src/lib/content.ts`: shared content and account contracts.
- `src/server/auth.ts`: password hashing, sessions, permissions, and authentication throttling.
- `src/server/catalog.ts`: validated content writes, revisions, seeding, search, and pagination.
- `src/server/db.ts`: connection, migrations, and database configuration.
- `database/migrations/`: ordered schema migrations.
- `scripts/`: privileged account setup/reset, consistent backups, and integration checks.

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for the data model, API contracts, security decisions, and extension points.

## Configuration

| Variable | Purpose |
| --- | --- |
| `DATABASE_PATH` | SQLite file; defaults to `./data/hub.sqlite`. Use durable storage. |
| `APP_URL` | Exact public origin used to validate browser writes, e.g. `https://learn.example.com`. |
| `ALLOW_REGISTRATION` | `true` enables reader signup. Disabled when omitted. |
| `COOKIE_SECURE` | Use `true` with HTTPS. Defaults to true in production. Local HTTP requires false. |
| `TRUST_PROXY` | Set true only behind a trusted proxy that overwrites `X-Forwarded-For`. Otherwise a shared authentication limit is applied. |

No API keys or external AI services are needed to run the library.

## Verify

```powershell
npm.cmd run typecheck
npm.cmd run build
npm.cmd run test:integration
```

The integration suite starts a production server on a temporary port, creates a separate database under `.test-data/`, and verifies authentication, authorization, content publishing, revision conflicts, bookmarks, completion, HTML escaping, backup integrity, and persistence after restarting. It stops its server when finished. It does not alter your main database. These checks do not replace browser interaction and accessibility testing.

## Deploy to a persistent Node server

```powershell
npm.cmd ci
npm.cmd run build
npm.cmd start
```

Use Node.js 24 LTS. Set `APP_URL` to the real HTTPS origin and `COOKIE_SECURE=true`. Run behind an HTTPS reverse proxy and process supervisor. Mount the database directory on durable local disk and keep backups off the host.

This SQLite implementation targets **one application instance on one persistent server**. Do not deploy it to an ephemeral/serverless filesystem, run multiple replicas against independently copied databases, or place the database on an unsupported network filesystem. For horizontal scaling, migrate the repository to managed PostgreSQL and use shared session/rate-limit storage.

### Docker

```text
docker build -t stl-ai-hub .
docker run -d --name stl-ai-hub -p 3000:3000 --mount source=stl-hub-data,target=/app/data --mount source=stl-hub-backups,target=/app/backups -e APP_URL=https://learn.example.com -e COOKIE_SECURE=true -e ALLOW_REGISTRATION=true stl-ai-hub
docker exec -it stl-ai-hub node scripts/admin.mjs
```

The Docker build uses Next.js standalone output and runs as the unprivileged `node` user. Put an HTTPS reverse proxy in front of it. Docker commands are provided for deployment; Docker execution is separate from the local integration suite.

For a local Docker preview over HTTP, use `APP_URL=http://localhost:3000` and `COOKIE_SECURE=false` instead.

## Back up and restore

```powershell
npm.cmd run db:backup
```

The backup command uses SQLite's online backup API so it includes committed WAL transactions. Backups contain account hashes, sessions, and activity: restrict access and encrypt off-host copies. Automate backups with your host's scheduler and test restores regularly.

To restore: stop every application process using this database; retain the existing database and its `-wal`/`-shm` files together in a recovery location; copy the selected backup to a **new filename**; point `DATABASE_PATH` to that new file; restart the application. Do not overwrite a live database or pair a restored file with an old WAL file. A restored backup can restore previously valid sessions; revoke sessions as part of recovery if that is inappropriate.

## Scope

This website teaches users how to work with AI and provides prompts and reference material. It does not call a model, train or provision agents, build dashboards inside another service, sync ERP records, send external messages, or execute external automations. Platform-specific tutorials, media uploads, SSO, editorial approval roles, and integrations can be added through the existing content and server layers. Public hosting, a domain, and a production backup schedule still need deployment configuration.
