CREATE TABLE users (
  id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  name TEXT NOT NULL, password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'reader' CHECK(role IN ('admin','reader')),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE sessions (
  token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at INTEGER NOT NULL
);
CREATE INDEX sessions_expiry ON sessions(expires_at);
CREATE TABLE content (
  id TEXT PRIMARY KEY, slug TEXT NOT NULL UNIQUE, title TEXT NOT NULL,
  description TEXT NOT NULL, topic TEXT NOT NULL, department TEXT NOT NULL,
  level TEXT NOT NULL, tags TEXT NOT NULL DEFAULT '[]', body TEXT NOT NULL,
  template TEXT NOT NULL DEFAULT '', minutes INTEGER NOT NULL DEFAULT 5,
  status TEXT NOT NULL CHECK(status IN ('draft','published')), version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX content_topic_status ON content(status, topic, updated_at);
CREATE TABLE revisions (
  id TEXT PRIMARY KEY, content_id TEXT NOT NULL REFERENCES content(id) ON DELETE CASCADE,
  version INTEGER NOT NULL, snapshot TEXT NOT NULL,
  editor_id TEXT REFERENCES users(id) ON DELETE SET NULL, created_at TEXT NOT NULL,
  UNIQUE(content_id, version)
);
CREATE TABLE activity (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content_id TEXT NOT NULL REFERENCES content(id) ON DELETE CASCADE,
  bookmarked INTEGER NOT NULL DEFAULT 0, completed INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(user_id, content_id)
);
CREATE TABLE rate_limits (key TEXT PRIMARY KEY, attempts INTEGER NOT NULL, reset_at INTEGER NOT NULL);
CREATE TABLE app_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
