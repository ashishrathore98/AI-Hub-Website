import { DatabaseSync } from "node:sqlite";
import { mkdirSync, readFileSync, readdirSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { randomBytes, randomUUID, scryptSync } from "node:crypto";
import { createInterface } from "node:readline/promises";

// Privileged operations stay in this local CLI; HTTP registration always creates a reader.
const reset = process.argv.includes("--reset");
const role = process.argv.includes("--reader") ? "reader" : "admin";
const cli = createInterface({ input: process.stdin, output: process.stdout });
try {
  const email = (process.env.ADMIN_EMAIL || await cli.question("Account email: ")).trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) throw new Error("Enter a valid email address.");
  const name = (process.env.ADMIN_NAME || (reset ? "" : await cli.question("Display name: "))).trim();
  if (!reset && (name.length < 2 || name.length > 80)) throw new Error("Name must contain 2–80 characters.");
  const password = process.env.ADMIN_PASSWORD || randomBytes(24).toString("base64url");
  if (password.length < 12 || password.length > 128) throw new Error("Password must contain 12–128 characters.");
  const path = resolve(process.env.DATABASE_PATH || "data/hub.sqlite");
  mkdirSync(dirname(path), { recursive: true });
  const db = new DatabaseSync(path);
  try {
    db.exec("PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;");
    db.exec("CREATE TABLE IF NOT EXISTS migrations(name TEXT PRIMARY KEY,applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)");
    for (const file of readdirSync("database/migrations").filter(f => f.endsWith(".sql")).sort()) {
      db.exec("BEGIN IMMEDIATE");
      try {
        if (!db.prepare("SELECT name FROM migrations WHERE name=?").get(file)) {
          db.exec(readFileSync(join("database/migrations", file), "utf8"));
          db.prepare("INSERT INTO migrations(name) VALUES(?)").run(file);
        }
        db.exec("COMMIT");
      } catch (e) { db.exec("ROLLBACK"); throw e; }
    }
    const existing = db.prepare("SELECT id FROM users WHERE email=?").get(email);
    if (existing && !reset) throw new Error("Account already exists. Use --reset to rotate its password without changing its role.");
    if (!existing && reset) throw new Error("Account not found. Omit --reset to create it.");
    const salt = randomBytes(16).toString("hex"); const hash = `${salt}:${scryptSync(password, salt, 64).toString("hex")}`;
    if (reset) {
      db.exec("BEGIN IMMEDIATE");
      try { db.prepare("UPDATE users SET password_hash=? WHERE id=?").run(hash, existing.id); db.prepare("DELETE FROM sessions WHERE user_id=?").run(existing.id); db.exec("COMMIT"); }
      catch (e) { db.exec("ROLLBACK"); throw e; }
    } else db.prepare("INSERT INTO users(id,email,name,password_hash,role) VALUES(?,?,?,?,?)").run(randomUUID(), email, name, hash, role);
    console.log(`${reset ? "Password reset" : `${role} account created`} for ${email}.`);
    if (!process.env.ADMIN_PASSWORD) console.log(`One-time generated password (store securely): ${password}`);
  } finally { db.close(); }
} catch (error) { console.error(error.message); process.exitCode = 1; }
finally { cli.close(); }
