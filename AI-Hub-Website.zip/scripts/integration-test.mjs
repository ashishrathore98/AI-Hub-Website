import assert from "node:assert/strict";
import { spawn, spawnSync } from "node:child_process";
import { randomUUID, randomBytes } from "node:crypto";
import { mkdirSync, readdirSync } from "node:fs";
import { resolve, join } from "node:path";
import { createServer } from "node:net";
import { once } from "node:events";
import { DatabaseSync } from "node:sqlite";

const directory = resolve(".test-data", randomUUID()); mkdirSync(directory, { recursive: true });
const socket = createServer(); socket.listen(0, "127.0.0.1"); await once(socket, "listening");
const port = socket.address().port; await new Promise(r => socket.close(r));
const base = `http://127.0.0.1:${port}`;
const password = randomBytes(24).toString("hex");
const env = { ...process.env, DATABASE_PATH: join(directory, "test.sqlite"), APP_URL: base, COOKIE_SECURE: "false", ALLOW_REGISTRATION: "true", TRUST_PROXY: "false", ADMIN_EMAIL: "admin@example.test", ADMIN_NAME: "Test Admin", ADMIN_PASSWORD: password, NEXT_TELEMETRY_DISABLED: "1", BACKUP_DIRECTORY: join(directory, "backups") };
const bootstrap = spawnSync(process.execPath, ["scripts/admin.mjs"], { env, encoding: "utf8" });
assert.equal(bootstrap.status, 0, bootstrap.stderr);
let server; let output = ""; let checks = 0;
function check(value, message) { assert.ok(value, message); checks++; }
async function request(path, { method = "GET", body, cookie, origin = base, raw } = {}) {
  const headers = {};
  if (method !== "GET") { headers.Origin = origin; headers["Content-Type"] = "application/json"; }
  if (cookie) headers.Cookie = cookie;
  const res = await fetch(`${base}${path}`, { method, headers, body: raw ?? (body === undefined ? undefined : JSON.stringify(body)), redirect: "manual", signal: AbortSignal.timeout(10_000) });
  const text = await res.text(); let data;
  try { data = JSON.parse(text); } catch { data = text; }
  return { status: res.status, data, headers: res.headers, cookie: res.headers.getSetCookie().map(c => c.split(";")[0]).join("; ") };
}
async function start() {
  server = spawn(process.execPath, ["node_modules/next/dist/bin/next", "start", "--hostname", "127.0.0.1", "--port", String(port)], { env, stdio: ["ignore", "pipe", "pipe"] });
  server.stdout.on("data", d => { output = (output + d).slice(-30000); }); server.stderr.on("data", d => { output = (output + d).slice(-30000); });
  for (let i = 0; i < 150; i++) {
    if (server.exitCode !== null) throw new Error(`Server stopped: ${output}`);
    try { if ((await request("/api/content")).status === 200) return; } catch { /* Wait for startup. */ }
    await new Promise(r => setTimeout(r, 200));
  }
  throw new Error(`Server failed to start: ${output}`);
}
async function stop() {
  if (!server || server.exitCode !== null) return;
  const exited = once(server, "exit"); server.kill("SIGTERM"); await exited;
}
try {
  await start();
  check((await request("/api/health")).data.status === "ok", "Health endpoint confirms database connectivity");
  const initial = await request("/api/content"); check(initial.data.total === 23, "Initial seed contains 15 prompts and 8 guides");
  check(initial.data.items.length === 12 && initial.data.pages === 2, "Pagination is enforced");
  const second = await request("/api/content?page=2"); check(second.data.items.length === 11, "Second page returns remaining resources");
  check((await request("/api/content?topic=Agents")).data.total === 2, "Topic filtering works");
  check((await request("/api/content?q=%25_")).data.total === 0, "Search escapes SQL wildcard characters");
  check((await request("/api/content?q=%27%20OR%201%3D1%20--")).data.total === 0, "Search treats SQL text as data");
  check((await request("/api/content?admin=true")).status === 401, "Anonymous users cannot list drafts");
  check((await request("/api/content", { method: "POST", body: {} })).status === 401, "Anonymous users cannot write content");
  const root = await request("/"); check(root.status === 200 && root.data.includes("Learn the skills"), "Public library renders on the server");
  const anonymousAdmin = await request("/admin");
  check(anonymousAdmin.status === 307 || anonymousAdmin.data.includes("url=/login?next=/admin"), "Admin page redirects unauthenticated visitors");
  for (const path of ["/paths", "/builder", "/login"]) check((await request(path)).status === 200, `${path} renders`);
  const badOrigin = await request("/api/auth/login", { method: "POST", body: {}, origin: "https://evil.example" }); check(badOrigin.status === 403, "Cross-origin mutations are rejected");
  check((await request("/api/auth/login", { method: "POST", raw: "{broken" })).status === 400, "Malformed JSON is rejected");
  check((await request("/api/auth/login", { method: "POST", body: { email: "admin@example.test", password: "incorrect-password" } })).status === 401, "Invalid credentials are rejected");
  const admin = await request("/api/auth/login", { method: "POST", body: { email: "admin@example.test", password } });
  check(admin.status === 200 && admin.data.user.role === "admin", "Administrator login works");
  const adminCookie = admin.cookie;
  check(admin.headers.get("set-cookie").includes("HttpOnly") && admin.headers.get("set-cookie").includes("SameSite=lax"), "Session cookie is HttpOnly and SameSite");
  const reader = await request("/api/auth/register", { method: "POST", body: { name: "Test Learner", email: "learner@example.test", password, role: "admin" } });
  check(reader.status === 200 && reader.data.user.role === "reader", "Registration cannot grant administrator access");
  const readerCookie = reader.cookie;
  check((await request("/api/content?admin=true", { cookie: readerCookie })).status === 403, "Reader cannot access admin data");
  check((await request("/api/content", { method: "POST", body: {}, cookie: readerCookie })).status === 403, "Reader cannot create content");
  check((await request("/api/content", { method: "POST", body: {}, cookie: adminCookie })).status === 400, "Content validation rejects incomplete input");
  check((await request("/api/content", { method: "POST", raw: JSON.stringify({ body: "x".repeat(100001) }), cookie: adminCookie })).status === 413, "Oversized input is rejected");
  const draft = { slug: "integration-test-guide", title: "Integration test guide", description: "An integration test guide with a unique phrase.", topic: "Agents", department: "Sales", level: "Beginner", tags: ["Testing"], body: "## A useful guide\n\nA database-backed lesson. <script>alert('unsafe')</script>\n\n1. Read the input.\n2. Verify the output.", template: "Summarize [input] and cite the evidence.", minutes: 4, status: "draft" };
  const created = await request("/api/content", { method: "POST", body: draft, cookie: adminCookie });
  check(created.status === 201 && created.data.content.version === 1, "Administrator creates a draft");
  let item = created.data.content;
  check((await request(`/api/content/${item.id}`)).status === 404, "Drafts are hidden from anonymous API readers");
  check((await request(`/learn/${item.slug}`)).status === 404, "Draft URLs are hidden from anonymous readers");
  check((await request(`/api/content/${item.id}?admin=true`, { cookie: adminCookie })).status === 200, "Administrator previews a draft");
  check((await request("/api/content", { method: "POST", body: draft, cookie: adminCookie })).status === 409, "Duplicate slugs are rejected");
  const published = await request(`/api/content/${item.id}`, { method: "PUT", body: { ...item, status: "published" }, cookie: adminCookie });
  check(published.status === 200 && published.data.content.version === 2, "Publishing creates a new content version"); item = published.data.content;
  check((await request("/api/content?q=unique%20phrase")).data.total === 1, "Published content is searchable");
  const rendered = await request(`/learn/${item.slug}`);
  check(rendered.status === 200 && rendered.data.includes("&lt;script&gt;"), "Lesson renders source HTML as text");
  check((await request(`/api/content/${item.id}`, { method: "PUT", body: { ...item, version: 1 }, cookie: adminCookie })).status === 409, "Stale edits are rejected");
  const history = await request(`/api/content/${item.id}?admin=true`, { cookie: adminCookie });
  check(history.data.revisions.length === 1 && history.data.revisions[0].content.status === "draft", "Revision history preserves the previous full version");
  check((await request("/api/activity", { method: "PUT", body: { contentId: item.id, field: "bookmarked", value: true }, cookie: readerCookie })).status === 200, "Learner saves a bookmark");
  check((await request("/api/activity", { method: "PUT", body: { contentId: item.id, field: "completed", value: true }, cookie: readerCookie })).status === 200, "Learner completes a lesson");
  const activity = await request("/api/activity", { cookie: readerCookie });
  check(activity.data.bookmarks.includes(item.id) && activity.data.completed.includes(item.id), "Both activity flags persist without overwriting each other");
  check((await request("/api/activity", { cookie: adminCookie })).data.bookmarks.length === 0, "Activity is isolated between users");
  check((await request("/saved", { cookie: readerCookie })).data.includes(item.title), "Saved resources page renders the bookmark");
  check((await request("/admin", { cookie: adminCookie })).status === 200, "Admin editor renders for an administrator");
  const db = new DatabaseSync(env.DATABASE_PATH, { readOnly: true });
  check(!db.prepare("SELECT token_hash FROM sessions").all().some(row => adminCookie.includes(row.token_hash)), "Database stores session hashes instead of raw tokens");
  check(db.prepare("SELECT password_hash FROM users WHERE email=?").get("admin@example.test").password_hash !== password, "Database stores a password hash"); db.close();
  const changed = await request("/api/auth/password", { method: "POST", body: { currentPassword: password, newPassword: `${password}new` }, cookie: readerCookie });
  check(changed.status === 200, "Learner can change their password");
  check((await request("/api/auth/me", { cookie: readerCookie })).data.user === null, "Password change revokes the old session");
  const newReaderCookie = changed.cookie;
  await stop(); await start();
  check((await request(`/api/content/${item.id}`)).data.content.version === 2, "Published content survives a server restart");
  check((await request("/api/activity", { cookie: newReaderCookie })).data.completed.includes(item.id), "Accounts, sessions, and progress survive a restart");
  const archived = await request(`/api/content/${item.id}`, { method: "PUT", body: { ...item, status: "draft" }, cookie: adminCookie });
  check(archived.status === 200 && (await request(`/api/content/${item.id}`)).status === 404, "Unpublishing removes public access");
  check(!(await request("/api/activity", { cookie: newReaderCookie })).data.bookmarks.includes(item.id), "Unpublished resources are hidden from learner activity");
  const backedUp = spawnSync(process.execPath, ["scripts/backup.mjs"], { env, encoding: "utf8" }); check(backedUp.status === 0, `Backup completes: ${backedUp.stderr}`);
  const backupPath = join(env.BACKUP_DIRECTORY, readdirSync(env.BACKUP_DIRECTORY)[0]); const copy = new DatabaseSync(backupPath, { readOnly: true });
  check(copy.prepare("PRAGMA integrity_check").get().integrity_check === "ok", "Backup passes SQLite integrity check"); copy.close();
  const loggedOut = await request("/api/auth/logout", { method: "POST", body: {}, cookie: adminCookie });
  check(loggedOut.status === 200 && (await request("/api/auth/me", { cookie: adminCookie })).data.user === null, "Logout revokes the session");
  console.log(`PASS: ${checks} integration checks (real production server, isolated SQLite database).`);
  console.log(`Test data retained at ${directory}`);
} catch (error) { console.error(error); console.error(output); process.exitCode = 1; }
finally { await stop(); }
