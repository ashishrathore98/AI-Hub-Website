import { DatabaseSync, backup } from "node:sqlite";
import { existsSync, mkdirSync } from "node:fs";
import { resolve, join } from "node:path";
const source = resolve(process.env.DATABASE_PATH || "data/hub.sqlite");
if (!existsSync(source)) throw new Error("Database not found. Start the app first.");
const directory = resolve(process.env.BACKUP_DIRECTORY || "backups"); mkdirSync(directory, { recursive: true });
const target = join(directory, `hub-${new Date().toISOString().replace(/[:.]/g, "-")}.sqlite`);
const db = new DatabaseSync(source, { readOnly: true });
try { await backup(db, target); console.log(`Consistent database backup saved: ${target}`); }
finally { db.close(); }
