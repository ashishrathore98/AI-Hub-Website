# Architecture and maintenance

## Boundaries

Next.js App Router provides both the website and its HTTP backend. Server-rendered pages read the catalog directly; browser interactions use route handlers. Database, authentication, and catalog modules import `server-only` to prevent accidental inclusion in browser bundles. Components share TypeScript contracts with the server but never receive password hashes or session tokens.

The application deliberately avoids a second API server while its needs fit a single process. SQL and content lifecycle rules are kept out of UI components. The catalog module is the repository boundary to replace when moving to another database.

## Data model

| Table | Responsibility |
| --- | --- |
| `users` | Unique case-insensitive email, display name, scrypt password hash, reader/admin role. |
| `sessions` | SHA-256 hash of a random opaque token, user reference, expiry. |
| `content` | Prompt or guide with topic, stable slug, body, optional template, status, version, timestamps. |
| `revisions` | Previous complete content snapshots, editor reference, and version. |
| `activity` | One bookmark/completion pair per user and resource. |
| `rate_limits` | Expiring counters for authentication/password attempts. |
| `app_meta` | One-time seed markers; restarting never overwrites editorial work. |
| `migrations` | Applied SQL migration names. |

Foreign keys are enabled on every connection. WAL mode and a busy timeout allow readers to proceed during short writes. Content updates and their snapshots commit in one transaction. Expected version numbers prevent lost updates. The application stores timestamps in UTC and displays article dates in Asia/Kolkata.

Migrations run in filename order with a write lock and a ledger. Add a new SQL migration for a schema change; never edit an applied migration to change existing databases. Back up first, apply in a staging copy, run the integration suite against the new schema, then release.

## API contracts

All JSON responses use `Cache-Control: no-store`. Errors use `{ "error": "message" }` with an appropriate status. All mutation requests require the exact allowed `Origin` header. JSON bodies are limited to 100 KB while being read.

| Method and route | Access | Behavior |
| --- | --- | --- |
| `GET /api/content` | Public | Published content, 12 per page; `q`, `topic`, `department`, `level`, `page`. |
| `GET /api/content?admin=true` | Admin | Includes drafts; additionally supports `status`. |
| `POST /api/content` | Admin | Validates and creates a resource. |
| `GET /api/content/:id-or-slug` | Public | Published resource or 404. |
| `GET /api/content/:id-or-slug?admin=true` | Admin | Any resource and up to 50 previous versions. |
| `PUT /api/content/:id` | Admin | Validated full update requiring current `version`; 409 on conflict. |
| `POST /api/auth/register` | Public, if enabled | Creates a reader and a session. |
| `POST /api/auth/login` | Public | Checks credentials and starts a session. |
| `POST /api/auth/logout` | Any visitor | Revokes the current session and clears its cookie. |
| `GET /api/auth/me` | Public | Current safe user record or null; registration setting. |
| `POST /api/auth/password` | Signed in | Checks current password, changes password, revokes existing sessions, starts a new session. |
| `GET /api/activity` | Signed in | Current user's published-resource bookmarks and completions. |
| `PUT /api/activity` | Signed in | Sets `bookmarked` or `completed` for one published resource. |
| `GET /api/health` | Public | Database connectivity check; 200 or 503, no internal details. |

Content input includes `slug`, `title`, `description`, `topic`, `department`, `level`, `tags`, `body`, `template`, `minutes`, and `status`. The server validates length limits, known category values, slug format, tag count, and reading time. Query values use prepared SQL statements. Search escapes `%`, `_`, and backslashes so keywords do not become SQL wildcard expressions.

An example content mutation:

```json
{
  "title": "Draft a weekly summary",
  "slug": "draft-a-weekly-summary",
  "description": "A practical guide for creating a checked weekly summary.",
  "topic": "Prompt engineering",
  "department": "All departments",
  "level": "Beginner",
  "tags": ["Writing", "Summaries"],
  "body": "## Start with the source\n\nGather the approved weekly report and check its date range.",
  "template": "Summarize [report] for [audience]. Cite the supplied evidence.",
  "minutes": 5,
  "status": "draft"
}
```

For updates, also include the resource's current `version`.

## Authentication and publication

Passwords use salted scrypt hashes with timing-safe comparison. Sessions use random 256-bit opaque tokens, stored only as hashes in the database. Cookies are HttpOnly, SameSite=Lax, and Secure by default in production. Sessions expire after seven days, rotate on authentication, and are revoked by logout or password changes. Administrative checks happen on every protected HTTP operation, independently of navigation visibility.

There is no HTTP route to create an administrator. Use the local CLI with control of the host. Public signup can be disabled. Email verification, SSO, and emailed password resets are future integrations, not implied features of the current password accounts.

The application checks mutation origins against `APP_URL` or the request origin when unset. Set an explicit `APP_URL` in deployment. Proxy IPs are trusted only when configured. Authentication limits are persisted in the database; without a trusted proxy all clients share the coarse request limit, in addition to per-email limits. Large public deployments should add edge rate limiting and monitoring.

Public reads always filter publication status, including direct URLs and related resources. Admins can preview drafts. The Markdown renderer constructs React text elements and never uses `dangerouslySetInnerHTML`; its supported syntax is intentionally small. Historical versions are accessible only through protected admin APIs.

## Extending the library

Most updates belong in Content studio and require no deployment. New published guides automatically appear under their topic and in learning paths. Paths order guides by level, creation time, and title; custom course ordering is a future schema extension. A topic is a controlled TypeScript value; to introduce one, update `src/lib/content.ts`, navigation, validation, and appropriate database migrations rather than adding an arbitrary label.

To add video or file uploads, add an object-storage service and a validated asset model; avoid storing large binaries in SQLite or accepting raw HTML. To add editorial approval, introduce explicit roles and approval records while keeping publication enforced on the server. To add model or automation integrations, use server-side credentials and narrow APIs with observable jobs and appropriate approval semantics. Do not place secret keys in `NEXT_PUBLIC_*` settings.

For multiple instances or a serverless host, move content, users, sessions, revisions, and activity to a managed database such as PostgreSQL. Preserve the route contracts and replace repository operations, use transactional migrations, and move throttling to shared storage. SQLite is appropriate for this release's single-server library, not an automatic horizontal-scaling solution.

## Verification and operations

The integration suite uses real HTTP requests against a built app and an isolated database. It checks public browsing, filters, pagination, auth boundaries, input errors, publication, stale edits, revision snapshots, escaped source HTML, personal activity, password/session lifecycle, restart persistence, and consistent backup integrity. UI click flows, browser layout, accessibility, container execution, and live hosting need their own acceptance checks before production rollout.

Use HTTPS, durable local storage, a process supervisor, off-host backups, and an assigned content owner. The backup script produces a consistent database snapshot using the native SQLite backup API. Verify recovery in a separate environment and retain a tested procedure with your deployment configuration.
